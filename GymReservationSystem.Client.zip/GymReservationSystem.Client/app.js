const API_BASE = 'http://localhost:8080/api';
let token = localStorage.getItem('token');
let currentUser = JSON.parse(localStorage.getItem('currentUser') || 'null');
let currentSection = 'trainings';
let editId = null;
let deleteTarget = null;

const sectionConfig = {
    trainings: {
        title: 'Treningi',
        subtitle: 'Upravljajte treninzima u vašoj teretani',
        endpoint: 'trainings',
        adminWriteOnly: true,
        columns: ['id', 'name', 'description', 'dateTime', 'durationMinutes', 'maxParticipants', 'trainerId', 'roomId', 'isActive'],
        headers: ['ID', 'Naziv', 'Opis', 'Datum/Vrijeme', 'Trajanje', 'Max osoba', 'Trener', 'Sala', 'Status'],
        fields: [
            { name: 'name', label: 'Naziv', type: 'text', fullWidth: true },
            { name: 'description', label: 'Opis', type: 'text', fullWidth: true },
            { name: 'dateTime', label: 'Datum i vrijeme', type: 'datetime-local' },
            { name: 'durationMinutes', label: 'Trajanje (min)', type: 'number' },
            { name: 'maxParticipants', label: 'Max polaznika', type: 'number' },
            { name: 'trainerId', label: 'Trener ID', type: 'number' },
            { name: 'roomId', label: 'Sala ID', type: 'number' },
            { name: 'isActive', label: 'Aktivan', type: 'checkbox' }
        ]
    },
    reservations: {
        title: 'Rezervacije',
        subtitle: 'Pregled i upravljanje rezervacijama',
        endpoint: 'reservations',
        adminWriteOnly: false,
        columns: ['id', 'userId', 'trainingId', 'reservationDate', 'status', 'createdAt'],
        headers: ['ID', 'Korisnik', 'Trening', 'Datum rez.', 'Status', 'Kreirano'],
        fields: [
            { name: 'userId', label: 'Korisnik ID', type: 'number' },
            { name: 'trainingId', label: 'Trening ID', type: 'number' },
            { name: 'reservationDate', label: 'Datum rezervacije', type: 'datetime-local' },
            { name: 'status', label: 'Status', type: 'select', options: ['Confirmed', 'Cancelled'] }
        ]
    },
    trainers: {
        title: 'Treneri',
        subtitle: 'Upravljajte trenerskim timom',
        endpoint: 'trainers',
        adminWriteOnly: true,
        columns: ['id', 'firstName', 'lastName', 'specialization', 'phone', 'email', 'isActive'],
        headers: ['ID', 'Ime', 'Prezime', 'Specijalizacija', 'Telefon', 'Email', 'Status'],
        fields: [
            { name: 'firstName', label: 'Ime', type: 'text' },
            { name: 'lastName', label: 'Prezime', type: 'text' },
            { name: 'specialization', label: 'Specijalizacija', type: 'text', fullWidth: true },
            { name: 'phone', label: 'Telefon', type: 'text' },
            { name: 'email', label: 'Email', type: 'email', fullWidth: true },
            { name: 'isActive', label: 'Aktivan', type: 'checkbox' }
        ]
    },
    rooms: {
        title: 'Sale',
        subtitle: 'Upravljajte salama za treninge',
        endpoint: 'rooms',
        adminWriteOnly: true,
        columns: ['id', 'name', 'capacity', 'description', 'isActive'],
        headers: ['ID', 'Naziv', 'Kapacitet', 'Opis', 'Status'],
        fields: [
            { name: 'name', label: 'Naziv', type: 'text' },
            { name: 'capacity', label: 'Kapacitet', type: 'number' },
            { name: 'description', label: 'Opis', type: 'text', fullWidth: true },
            { name: 'isActive', label: 'Aktivna', type: 'checkbox' }
        ]
    },
    memberships: {
        title: 'Članarine',
        subtitle: 'Upravljajte vrstama članarina',
        endpoint: 'memberships',
        adminWriteOnly: true,
        columns: ['id', 'name', 'durationDays', 'price', 'description', 'isActive'],
        headers: ['ID', 'Naziv', 'Trajanje', 'Cijena', 'Opis', 'Status'],
        fields: [
            { name: 'name', label: 'Naziv', type: 'text' },
            { name: 'durationDays', label: 'Trajanje (dana)', type: 'number' },
            { name: 'price', label: 'Cijena (€)', type: 'number', step: '0.01' },
            { name: 'description', label: 'Opis', type: 'text', fullWidth: true },
            { name: 'isActive', label: 'Aktivna', type: 'checkbox' }
        ]
    },
    users: {
        title: 'Korisnici',
        subtitle: 'Upravljajte korisnicima sustava',
        endpoint: 'users',
        adminOnly: true,
        adminWriteOnly: true,
        columns: ['id', 'firstName', 'lastName', 'email', 'phone', 'isActive', 'membershipId'],
        headers: ['ID', 'Ime', 'Prezime', 'Email', 'Telefon', 'Status', 'Članarina'],
        fields: [
            { name: 'firstName', label: 'Ime', type: 'text' },
            { name: 'lastName', label: 'Prezime', type: 'text' },
            { name: 'email', label: 'Email', type: 'email', fullWidth: true },
            { name: 'phone', label: 'Telefon', type: 'text' },
            { name: 'isActive', label: 'Aktivan', type: 'checkbox' },
            { name: 'membershipId', label: 'Članarina ID', type: 'number' }
        ]
    },
    roles: {
        title: 'Uloge',
        subtitle: 'Upravljajte ulogama u sustavu',
        endpoint: 'roles',
        adminOnly: true,
        adminWriteOnly: true,
        columns: ['id', 'name', 'description'],
        headers: ['ID', 'Naziv', 'Opis'],
        fields: [
            { name: 'name', label: 'Naziv', type: 'text' },
            { name: 'description', label: 'Opis', type: 'text', fullWidth: true }
        ]
    },
    userroles: {
        title: 'Korisnik - Uloga',
        subtitle: 'Dodijelite uloge korisnicima',
        endpoint: 'userroles',
        adminOnly: true,
        adminWriteOnly: true,
        columns: ['id', 'userId', 'roleId'],
        headers: ['ID', 'Korisnik ID', 'Uloga ID'],
        fields: [
            { name: 'userId', label: 'Korisnik ID', type: 'number' },
            { name: 'roleId', label: 'Uloga ID', type: 'number' }
        ]
    }
};

// ==================== INIT ====================
document.addEventListener('DOMContentLoaded', () => {
    if (token && currentUser) {
        showDashboard();
    } else {
        showAuth();
    }
});

function showAuth() {
    document.getElementById('authScreen').style.display = 'flex';
    document.getElementById('dashboard').style.display = 'none';
}

function showDashboard() {
    document.getElementById('authScreen').style.display = 'none';
    document.getElementById('dashboard').style.display = 'flex';
    updateUserUI();
    navigateTo(currentSection);
}

function updateUserUI() {
    if (!currentUser) return;
    const isAdmin = currentUser.role === 'Admin';
    const name = currentUser.email.split('@')[0];
    document.getElementById('userAvatar').textContent = name.charAt(0).toUpperCase();
    document.getElementById('sidebarUserName').textContent = name;
    document.getElementById('sidebarUserRole').textContent = isAdmin ? 'Administrator' : 'Korisnik';

    document.querySelectorAll('.admin-section').forEach(el => {
        el.style.display = isAdmin ? 'block' : 'none';
    });
    document.querySelectorAll('.admin-item').forEach(el => {
        el.style.display = isAdmin ? 'flex' : 'none';
    });
}

// ==================== AUTH ====================
function switchAuthTab(tab) {
    document.querySelectorAll('.auth-tab').forEach(t => t.classList.remove('active'));
    if (tab === 'login') {
        document.querySelectorAll('.auth-tab')[0].classList.add('active');
        document.getElementById('loginForm').style.display = 'flex';
        document.getElementById('registerForm').style.display = 'none';
    } else {
        document.querySelectorAll('.auth-tab')[1].classList.add('active');
        document.getElementById('loginForm').style.display = 'none';
        document.getElementById('registerForm').style.display = 'flex';
    }
}

async function handleLogin(e) {
    e.preventDefault();
    try {
        const data = await apiCall('auth/login', 'POST', {
            email: document.getElementById('loginEmail').value,
            password: document.getElementById('loginPassword').value
        });
        token = data.token;
        currentUser = { email: data.email, role: data.role };
        localStorage.setItem('token', token);
        localStorage.setItem('currentUser', JSON.stringify(currentUser));
        showToast('Uspješna prijava', 'success');
        showDashboard();
    } catch (err) {
        showToast(err.message, 'error');
    }
}

async function handleRegister(e) {
    e.preventDefault();
    try {
        const data = await apiCall('auth/register', 'POST', {
            firstName: document.getElementById('regFirstName').value,
            lastName: document.getElementById('regLastName').value,
            email: document.getElementById('regEmail').value,
            password: document.getElementById('regPassword').value,
            phone: document.getElementById('regPhone').value
        });
        token = data.token;
        currentUser = { email: data.email, role: data.role };
        localStorage.setItem('token', token);
        localStorage.setItem('currentUser', JSON.stringify(currentUser));
        showToast('Račun je uspješno kreiran', 'success');
        showDashboard();
    } catch (err) {
        showToast(err.message, 'error');
    }
}

function logout() {
    token = null;
    currentUser = null;
    localStorage.removeItem('token');
    localStorage.removeItem('currentUser');
    showAuth();
    showToast('Uspješno ste se odjavili', 'success');
}

// ==================== API ====================
async function apiCall(endpoint, method = 'GET', body = null) {
    const headers = { 'Content-Type': 'application/json' };
    if (token) headers['Authorization'] = `Bearer ${token}`;

    const options = { method, headers };
    if (body) options.body = JSON.stringify(body);

    const response = await fetch(`${API_BASE}/${endpoint}`, options);
    if (response.status === 401) {
        logout();
        throw new Error('Sesija je istekla');
    }
    if (!response.ok) {
        const err = await response.json().catch(() => ({ error: response.statusText }));
        throw new Error(err.error || err.message || 'Greška na serveru');
    }
    if (response.status === 204) return null;
    return response.json();
}

// ==================== NAVIGATION ====================
function navigateTo(section, event) {
    if (event) event.preventDefault();
    currentSection = section;
    const config = sectionConfig[section];
    if (!config) return;

    const isAdmin = currentUser && currentUser.role === 'Admin';
    if (config.adminOnly && !isAdmin) return;

    document.getElementById('pageTitle').textContent = config.title;
    document.getElementById('pageSubtitle').textContent = config.subtitle;

    const canWrite = !config.adminWriteOnly || isAdmin;
    document.getElementById('addBtn').style.display = canWrite ? 'inline-flex' : 'none';

    document.querySelectorAll('.nav-item').forEach(a => {
        a.classList.toggle('active', a.dataset.section === section);
    });

    loadData(section);
}

// ==================== DATA ====================
async function loadData(section) {
    const config = sectionConfig[section];
    const spinner = document.getElementById('loadingSpinner');
    const tableHead = document.getElementById('tableHead');
    const tableBody = document.getElementById('tableBody');
    const emptyState = document.getElementById('emptyState');

    spinner.style.display = 'flex';
    emptyState.style.display = 'none';
    tableBody.innerHTML = '';
    tableHead.innerHTML = '';

    try {
        let data;
        if (section === 'reservations' && currentUser && currentUser.role !== 'Admin') {
            data = await apiCall(`reservations/user/${1}`);
        } else {
            data = await apiCall(config.endpoint);
        }

        spinner.style.display = 'none';

        if (!data || data.length === 0) {
            emptyState.style.display = 'block';
            return;
        }

        tableHead.innerHTML = '<tr>' +
            config.headers.map(h => `<th>${h}</th>`).join('') +
            '<th style="text-align:right">Akcije</th></tr>';

        const isAdmin = currentUser && currentUser.role === 'Admin';
        const canWrite = !config.adminWriteOnly || isAdmin;

        data.forEach(item => {
            const tr = document.createElement('tr');
            config.columns.forEach(col => {
                const td = document.createElement('td');
                const val = item[col];

                if (col === 'isActive') {
                    td.innerHTML = val
                        ? '<span class="badge badge-yes">Aktivan</span>'
                        : '<span class="badge badge-no">Neaktivan</span>';
                } else if (col === 'status') {
                    td.innerHTML = val === 'Confirmed'
                        ? '<span class="badge badge-confirmed">Potvrđena</span>'
                        : '<span class="badge badge-cancelled">Otkazana</span>';
                } else if (col === 'price') {
                    td.innerHTML = `<strong>${Number(val).toFixed(2)} €</strong>`;
                } else if (col === 'dateTime' || col === 'reservationDate' || col === 'createdAt') {
                    td.textContent = val ? new Date(val).toLocaleString('hr-HR', {
                        day: '2-digit', month: '2-digit', year: 'numeric',
                        hour: '2-digit', minute: '2-digit'
                    }) : '-';
                } else if (col === 'id') {
                    td.innerHTML = `<span style="color:var(--text-muted); font-weight:500">#${val}</span>`;
                } else if (col === 'durationDays') {
                    td.textContent = val + ' dana';
                } else if (col === 'durationMinutes') {
                    td.textContent = val + ' min';
                } else {
                    td.textContent = val ?? '-';
                }
                tr.appendChild(td);
            });

            const actionTd = document.createElement('td');
            actionTd.style.textAlign = 'right';
            if (canWrite) {
                actionTd.innerHTML = `
                    <div class="cell-actions" style="justify-content:flex-end">
                        <button class="btn-action" onclick="openEditModal(${item.id})" title="Uredi">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                        </button>
                        <button class="btn-action btn-action-danger" onclick="openDeleteModal(${item.id})" title="Obriši">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3,6 5,6 21,6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/></svg>
                        </button>
                    </div>`;
            } else {
                actionTd.textContent = '-';
            }
            tr.appendChild(actionTd);
            tableBody.appendChild(tr);
        });
    } catch (err) {
        spinner.style.display = 'none';
        tableBody.innerHTML = `<tr><td colspan="99" class="table-error">${err.message}</td></tr>`;
    }
}

// ==================== CRUD MODAL ====================
function openCreateModal() {
    editId = null;
    const config = sectionConfig[currentSection];
    document.getElementById('crudTitle').textContent = `Dodaj ${config.title.toLowerCase().replace(/s$/, '')}`;
    renderCrudFields(config.fields, {});
    document.getElementById('crudModal').classList.add('active');
}

async function openEditModal(id) {
    editId = id;
    const config = sectionConfig[currentSection];
    document.getElementById('crudTitle').textContent = `Uredi ${config.title.toLowerCase().replace(/s$/, '')}`;
    try {
        const item = await apiCall(`${config.endpoint}/${id}`);
        renderCrudFields(config.fields, item);
        document.getElementById('crudModal').classList.add('active');
    } catch (err) {
        showToast(err.message, 'error');
    }
}

function renderCrudFields(fields, data) {
    const container = document.getElementById('crudFields');
    let html = '<div class="crud-grid">';

    fields.forEach(f => {
        const val = data[f.name];
        const cls = f.fullWidth ? ' full-width' : '';

        if (f.type === 'checkbox') {
            html += `
                <div class="crud-checkbox${cls}">
                    <input type="checkbox" name="${f.name}" id="field_${f.name}" ${val ? 'checked' : ''}>
                    <label for="field_${f.name}">${f.label}</label>
                </div>`;
        } else if (f.type === 'select') {
            html += `
                <div class="crud-field${cls}">
                    <label for="field_${f.name}">${f.label}</label>
                    <select name="${f.name}" id="field_${f.name}">
                        ${f.options.map(o => `<option value="${o}" ${val === o ? 'selected' : ''}>${o}</option>`).join('')}
                    </select>
                </div>`;
        } else {
            let inputVal = val ?? '';
            if ((f.type === 'datetime-local' || f.type === 'date') && inputVal) {
                inputVal = new Date(inputVal).toISOString().slice(0, 16);
            }
            html += `
                <div class="crud-field${cls}">
                    <label for="field_${f.name}">${f.label}</label>
                    <input type="${f.type}" name="${f.name}" id="field_${f.name}"
                           value="${inputVal}" ${f.step ? `step="${f.step}"` : ''} ${f.type === 'number' ? 'min="0"' : ''}>
                </div>`;
        }
    });

    html += '</div>';
    container.innerHTML = html;
}

function closeCrudModal() {
    document.getElementById('crudModal').classList.remove('active');
}

async function handleCrudSubmit(e) {
    e.preventDefault();
    const config = sectionConfig[currentSection];
    const data = {};

    config.fields.forEach(f => {
        const el = document.getElementById(`field_${f.name}`);
        if (f.type === 'checkbox') {
            data[f.name] = el.checked;
        } else if (f.type === 'number') {
            data[f.name] = el.value !== '' ? Number(el.value) : null;
        } else {
            data[f.name] = el.value;
        }
    });

    try {
        if (editId) {
            await apiCall(`${config.endpoint}/${editId}`, 'PUT', data);
            showToast('Zapis je uspješno ažuriran', 'success');
        } else {
            await apiCall(config.endpoint, 'POST', data);
            showToast('Zapis je uspješno kreiran', 'success');
        }
        closeCrudModal();
        loadData(currentSection);
    } catch (err) {
        showToast(err.message, 'error');
    }
}

// ==================== DELETE MODAL ====================
function openDeleteModal(id) {
    deleteTarget = id;
    document.getElementById('deleteModal').classList.add('active');
    document.getElementById('confirmDeleteBtn').onclick = confirmDelete;
}

function closeDeleteModal() {
    document.getElementById('deleteModal').classList.remove('active');
    deleteTarget = null;
}

async function confirmDelete() {
    if (!deleteTarget) return;
    const config = sectionConfig[currentSection];
    try {
        await apiCall(`${config.endpoint}/${deleteTarget}`, 'DELETE');
        showToast('Zapis je uspješno obrisan', 'success');
        closeDeleteModal();
        loadData(currentSection);
    } catch (err) {
        showToast(err.message, 'error');
        closeDeleteModal();
    }
}

// ==================== TOAST ====================
function showToast(message, type = 'info') {
    const container = document.getElementById('toastContainer');
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;

    let iconSvg = '';
    if (type === 'success') {
        iconSvg = '<svg class="toast-icon" viewBox="0 0 24 24" fill="none" stroke="#10b981" stroke-width="2"><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22,4 12,14.01 9,11.01"/></svg>';
    } else if (type === 'error') {
        iconSvg = '<svg class="toast-icon" viewBox="0 0 24 24" fill="none" stroke="#ef4444" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M15 9l-6 6M9 9l6 6"/></svg>';
    } else {
        iconSvg = '<svg class="toast-icon" viewBox="0 0 24 24" fill="none" stroke="#f59e0b" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/></svg>';
    }

    toast.innerHTML = `${iconSvg}<span class="toast-message">${message}</span>`;
    container.appendChild(toast);

    setTimeout(() => {
        toast.classList.add('toast-out');
        toast.addEventListener('animationend', () => toast.remove());
    }, 3500);
}

// Close modals on overlay click
document.getElementById('crudModal').addEventListener('click', function(e) {
    if (e.target === this) closeCrudModal();
});
document.getElementById('deleteModal').addEventListener('click', function(e) {
    if (e.target === this) closeDeleteModal();
});

// Close modals on Escape
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        closeCrudModal();
        closeDeleteModal();
    }
});