Koristi ovo za migracije: dotnet ef migrations add InitialCreate `
--startup-project "C:\Users\Blaž Rodić\Desktop\GymReservationSystem\GymReservationSystem\GymReservationSystem.API.csproj" `
--project "C:\Users\Blaž Rodić\Desktop\GymReservationSystem\GymReservationSystem.Infrastructure\GymReservationSystem.Infrastructure.csproj"

i onda ovo: dotnet ef database update `
--startup-project "C:\Users\Blaž Rodić\Desktop\GymReservationSystem\GymReservationSystem\GymReservationSystem.API.csproj" `
--project "C:\Users\Blaž Rodić\Desktop\GymReservationSystem\GymReservationSystem.Infrastructure\GymReservationSystem.Infrastructure.csproj"

Za pokretanje frontenda: u Terminal ide npx serve .